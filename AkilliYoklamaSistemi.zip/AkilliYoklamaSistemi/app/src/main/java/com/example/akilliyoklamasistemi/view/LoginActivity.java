package com.example.akilliyoklamasistemi.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.akilliyoklamasistemi.managers.AuthService;
import com.example.akilliyoklamasistemi.managers.DeviceUtil;
import com.example.akilliyoklamasistemi.databinding.ActivityLoginBinding;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
     FirebaseAuth mAut;
    private ActivityLoginBinding binding;
    private AuthService authService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        authService = new AuthService();




        binding.signupText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

    }

    public void signIn(View view){
        String email = binding.eMail.getText().toString();
        String password = binding.password.getText().toString();
        String deviceId = DeviceUtil.getDeviceId(this);
        authService.Login(email,password,deviceId,this);
    }
}