package com.example.akilliyoklamasistemi.models;

public class CourseModel {

    String courseName;
    String courseTeacher;


    public CourseModel(String courseName, String courseTeacher) {
        this.courseName = courseName;
        this.courseTeacher = courseTeacher;
    }


    public String getCourseName() {
        return courseName;
    }

    public String getCourseTeacher() {
        return courseTeacher;
    }
}
