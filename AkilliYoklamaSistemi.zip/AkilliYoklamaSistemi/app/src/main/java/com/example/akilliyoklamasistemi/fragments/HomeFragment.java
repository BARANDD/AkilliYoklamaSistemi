package com.example.akilliyoklamasistemi.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.akilliyoklamasistemi.adapter.CourseFragmentAdapter;
import com.example.akilliyoklamasistemi.adapter.RecyclerViewInterface;
import com.example.akilliyoklamasistemi.databinding.FragmentHomeBinding;
import com.example.akilliyoklamasistemi.managers.ClientManager;
import com.example.akilliyoklamasistemi.models.CourseModel;
import com.example.akilliyoklamasistemi.view.MainActivity3;
import com.google.firebase.auth.FirebaseAuth;
import java.util.ArrayList;
import java.util.Objects;

public class HomeFragment extends Fragment implements RecyclerViewInterface {


    private FragmentHomeBinding binding;
    private ArrayList<CourseModel> courseModels;
    private CourseFragmentAdapter adapter;
    private ClientManager clientManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        courseModels = new ArrayList<>();
        clientManager = new ClientManager(requireContext()); // requireContext() kullanarak null değer döndürme riskini azaltın
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recyclerView = binding.enrolledCoursesRecyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext())); // requireContext() kullanarak null değer döndürme riskini azaltın
        adapter = new CourseFragmentAdapter(requireContext(), courseModels,this);
        recyclerView.setAdapter(adapter);
        getData();


    }

    private void getData() {
        String userId = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
        clientManager.getUserEnrolledCourseDetails(userId, new ClientManager.OnEnrolledCourseDetailsListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onCourseDetailsFetched(CourseModel courseDetails) {
                if (courseDetails != null) {
                    courseModels.add(courseDetails);
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(requireContext(), "Veri alınırken bir hata oluştu", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onItemClick(int position) {
        CourseModel model = courseModels.get(position);

        clientManager.fetchCourseDetails(model.getCourseName(), model.getCourseTeacher(), new ClientManager.CourseDetailsListener() {
            @Override
            public void onCourseDetailsFetched(String teacherId, boolean isCourseStarted, String courseId) {
                launchCourseDetailsActivity(model, teacherId, isCourseStarted, courseId);
            }

            @Override
            public void onFailure(String errorMessage) {
                showErrorToast(errorMessage);
            }
        });
    }

    private void launchCourseDetailsActivity(CourseModel model, String teacherId, boolean isCourseStarted, String courseId) {
        Intent intent = new Intent(requireContext(), MainActivity3.class);
        intent.putExtra("courseName", model.getCourseName());
        intent.putExtra("teacherName", model.getCourseTeacher());
        intent.putExtra("teacherId", teacherId);
        intent.putExtra("userId", FirebaseAuth.getInstance().getCurrentUser().getUid());
        intent.putExtra("isCourseStarted", isCourseStarted);
        intent.putExtra("courseId", courseId);
        startActivity(intent);
    }

    private void showErrorToast(String errorMessage) {
        Toast.makeText(requireContext(), "Failed to fetch course details: " + errorMessage, Toast.LENGTH_SHORT).show();
    }




}
