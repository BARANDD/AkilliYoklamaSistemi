package com.example.akilliyoklamasistemi.models;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.example.akilliyoklamasistemi.managers.TeacherManager;

import java.util.ArrayList;
import java.util.List;

    public class TeacherViewModel extends AndroidViewModel {

    private final TeacherManager teacherManager;
    private final MutableLiveData<Boolean> refreshTrigger = new MutableLiveData<>(true);

    public TeacherViewModel(Application application) {
        super(application);
        teacherManager = new TeacherManager(application);
    }

    public LiveData<List<String>> getTeachingCourses() {
        return Transformations.switchMap(refreshTrigger, input -> teacherManager.getTeachingCourses());
    }

    public LiveData<List<String>> getCourseNames(List<String> courseIds) {
        List<LiveData<String>> courseNamesLiveDataList = new ArrayList<>();
        for (String courseId : courseIds) {
            courseNamesLiveDataList.add(teacherManager.getCourseName(courseId));
        }

        return Transformations.map(MergeLiveData.merge(courseNamesLiveDataList), input -> {
            List<String> courseNames = new ArrayList<>();
            for (String name : input) {
                if (name != null) {
                    courseNames.add(name);
                }
            }
            return courseNames;
        });
    }

    public void refreshData() {
        refreshTrigger.setValue(true);
    }
}
