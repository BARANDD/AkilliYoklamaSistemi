package com.example.akilliyoklamasistemi.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.adapter.CourseFragmentAdapterT;
import com.example.akilliyoklamasistemi.adapter.RecyclerViewInterface;
import com.example.akilliyoklamasistemi.databinding.FragmentTeacherHomeBinding;
import com.example.akilliyoklamasistemi.managers.TeacherManager;
import com.example.akilliyoklamasistemi.models.TeacherCourseModel;
import com.example.akilliyoklamasistemi.models.TeacherViewModel;
import com.example.akilliyoklamasistemi.view.MainActivity2;

import java.util.ArrayList;

public class TeacherHomeFragment extends Fragment implements RecyclerViewInterface {

    private FragmentTeacherHomeBinding binding;
    private ArrayList<TeacherCourseModel> courseModels;
    private CourseFragmentAdapterT adapterT;

    private TeacherManager teacherManager;

    private TeacherViewModel teacherViewModel;



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        courseModels = new ArrayList<>();
        teacherManager = new TeacherManager(requireContext());
        teacherViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(TeacherViewModel.class);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTeacherHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapterT = new CourseFragmentAdapterT(requireContext(),courseModels,this);
        binding.enrolledCoursesRecyclerViewT.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.enrolledCoursesRecyclerViewT.setAdapter(adapterT);


        observeViewModel();
    }

    private void observeViewModel() {
        teacherViewModel.getTeachingCourses().observe(getViewLifecycleOwner(), courseIds -> {
            if (courseIds.isEmpty()) {
                Toast.makeText(getActivity(), "No teaching courses found", Toast.LENGTH_SHORT).show();
            } else {
                teacherViewModel.getCourseNames(courseIds).observe(getViewLifecycleOwner(), courseNames -> {
                    courseModels.clear();
                    for (String name : courseNames) {
                        courseModels.add(new TeacherCourseModel(name));
                    }
                    adapterT.notifyDataSetChanged();
                });
            }
        });
    }
/**/
    @Override
    public void onItemClick(int position) {
        TeacherCourseModel courseModel = courseModels.get(position);

        teacherManager.findCourseDetails(courseModel.getCourseName(), new TeacherManager.CourseDetailsListener() {
            @Override
            public void onSuccess(String courseId, String enrollmentCode) {
                String userId = teacherManager.getUserId();

                if (userId != null) {
                    Intent intent = new Intent(requireContext(), MainActivity2.class);
                    intent.putExtra("userId", userId);
                    intent.putExtra("courseId", courseId);
                    intent.putExtra("courseName", courseModel.getCourseName());
                    intent.putExtra("enrollmentCode", enrollmentCode);
                    startActivity(intent);
                } else {
                    Toast.makeText(getActivity(), "Failed to get user ID", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
}