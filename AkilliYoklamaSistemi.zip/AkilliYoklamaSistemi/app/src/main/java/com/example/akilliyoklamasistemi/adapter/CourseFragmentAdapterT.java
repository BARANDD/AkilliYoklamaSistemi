package com.example.akilliyoklamasistemi.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.akilliyoklamasistemi.databinding.RecyclerItemCoursesTeacherBinding;
import com.example.akilliyoklamasistemi.models.TeacherCourseModel;

import java.util.ArrayList;

public class CourseFragmentAdapterT extends RecyclerView.Adapter<CourseFragmentAdapterT.CouresHolder> {
    private final RecyclerViewInterface recyclerViewInterface;
    ArrayList<TeacherCourseModel> arrayList;
    Context context;

    public CourseFragmentAdapterT(Context context,ArrayList<TeacherCourseModel> arrayList, RecyclerViewInterface recyclerViewInterface) {
        this.arrayList = arrayList;
        this.context = context;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public CouresHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerItemCoursesTeacherBinding binding = RecyclerItemCoursesTeacherBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new CouresHolder(binding,recyclerViewInterface);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull CouresHolder holder, int position) {
        holder.binding.courseNameTextViewT.setText(arrayList.get(position).getCourseName());
    }

    public class CouresHolder extends RecyclerView.ViewHolder{

        RecyclerItemCoursesTeacherBinding binding;

    public CouresHolder(@NonNull RecyclerItemCoursesTeacherBinding binding,RecyclerViewInterface recyclerViewInterface) {
        super(binding.getRoot());
        this.binding = binding;
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (recyclerViewInterface != null){
                    int pos = getAdapterPosition();

                    if (pos != RecyclerView.NO_POSITION){
                        recyclerViewInterface.onItemClick(pos);
                    }
                }
            }
        });
    }
}



}
