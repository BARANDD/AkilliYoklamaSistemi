package com.example.akilliyoklamasistemi.view;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.adapter.viewPagerAdapter;
import com.example.akilliyoklamasistemi.adapter.viewPagerAdapter2;
import com.example.akilliyoklamasistemi.databinding.ActivityLoginBinding;
import com.example.akilliyoklamasistemi.databinding.ActivityStudentBinding;
import com.example.akilliyoklamasistemi.fragments.HomeFragment;
import com.example.akilliyoklamasistemi.fragments.TeacherHomeFragment;
import com.google.android.material.tabs.TabLayout;

public class StudentActivity extends AppCompatActivity {

    ActivityStudentBinding binding;
    viewPagerAdapter vpAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityStudentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        vpAdapter = new viewPagerAdapter(this);
        binding.viewPager.setAdapter(vpAdapter);

        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.tabLayout.getTabAt(position).select();
            }
        });


    }

    public void refreshTeacherHomeFragment1() {
        TeacherHomeFragment teacherHomeFragment = new TeacherHomeFragment();
        vpAdapter = new viewPagerAdapter(this);
        vpAdapter.notifyDataSetChanged();
        binding.viewPager.setAdapter(vpAdapter);

        // 2. ViewPager'ı ilk sekme konumuna getir
        binding.viewPager.setCurrentItem(0);
    }
}

