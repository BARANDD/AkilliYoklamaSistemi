package com.example.akilliyoklamasistemi.fragments;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.Manifest;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.databinding.FragmentCourseRegistrationBinding;
import com.example.akilliyoklamasistemi.managers.ClientManager;
import com.example.akilliyoklamasistemi.view.StudentActivity;
import com.example.akilliyoklamasistemi.view.TeacherActivity;

public class CourseRegistrationFragment extends Fragment {

    private FragmentCourseRegistrationBinding binding;
    private ClientManager clientManager;
    private static final int PERMISSION_REQUEST_LOCATION = 1001;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clientManager = new ClientManager(requireContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentCourseRegistrationBinding.inflate(inflater, container, false);

        // Konum iznini talep et
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_LOCATION);
        }

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enrollmentCode = binding.enrollmentCodeEditText.getText().toString().trim();
                if (enrollmentCode.isEmpty()){
                    Toast.makeText(getActivity(), "Please enter an enrollment code.", Toast.LENGTH_SHORT).show();
                    return;
                }
                clientManager.registerForCourse(enrollmentCode, new ClientManager.CourseRegistrationListener() {
                    @Override
                    public void onRegistrationSuccess() {

                        Toast.makeText(requireContext(), "Successfully registered for the course.", Toast.LENGTH_SHORT).show();
                        if (getActivity() instanceof StudentActivity) {

                            ((StudentActivity) getActivity()).refreshTeacherHomeFragment1();
                        }
                    }

                    @Override
                    public void onRegistrationFailure(String errorMessage) {
                        Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
