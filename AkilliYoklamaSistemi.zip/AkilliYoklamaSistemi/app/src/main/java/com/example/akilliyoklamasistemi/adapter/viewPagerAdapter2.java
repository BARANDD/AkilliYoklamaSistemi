package com.example.akilliyoklamasistemi.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.akilliyoklamasistemi.fragments.ChangePasswordFragment;
import com.example.akilliyoklamasistemi.fragments.CourseRegistrationFragment;
import com.example.akilliyoklamasistemi.fragments.CreateCourseFragment;
import com.example.akilliyoklamasistemi.fragments.HomeFragment;
import com.example.akilliyoklamasistemi.fragments.TeacherHomeFragment;

public class viewPagerAdapter2 extends FragmentStateAdapter {
    public viewPagerAdapter2(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new TeacherHomeFragment();
            case 1:
                return new CreateCourseFragment();
            case 2:
                return new ChangePasswordFragment();
            default:
                return new TeacherHomeFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}

