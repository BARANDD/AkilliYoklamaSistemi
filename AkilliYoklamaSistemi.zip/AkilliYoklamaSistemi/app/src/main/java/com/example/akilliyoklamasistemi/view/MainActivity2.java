package com.example.akilliyoklamasistemi.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.databinding.ActivityMain2Binding;
import com.example.akilliyoklamasistemi.managers.TeacherManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    ActivityMain2Binding binding;

    private String userId;
    private String courseId;
    private String courseName;
    private String enrollmentCode;

    private FusedLocationProviderClient fusedLocationClient;
    public TeacherManager manager;

    private ListView studentAttendanceListView;
    private ArrayAdapter<String> adapter;
    private List<String> studentAttendanceList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMain2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        manager = new TeacherManager(this);
        userId = getIntent().getStringExtra("userId");
        courseId = getIntent().getStringExtra("courseId");
        courseName = getIntent().getStringExtra("courseName");
        enrollmentCode = getIntent().getStringExtra("enrollmentCode");

        binding.courseNameTextView.setText(courseName);
        binding.enrollmentCodeTextView.setText(enrollmentCode);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        studentAttendanceListView = findViewById(R.id.studentAttendanceListView);
        studentAttendanceList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, studentAttendanceList);
        studentAttendanceListView.setAdapter(adapter);

        checkCourseStatus();


        binding.startCourseButton.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(MainActivity2.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(MainActivity2.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity2.this, "Location permissions are not granted.", Toast.LENGTH_SHORT).show();
                return;
            }

            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            startAttendance(location);
                        } else {
                            Toast.makeText(MainActivity2.this, "Unable to get current location.", Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        binding.endCourseButton.setOnClickListener(v -> endAttendance());
    }

    private void checkCourseStatus() {
        manager.checkCourseStatus(courseId, new TeacherManager.CourseStatusListener() {
            @Override
            public void onStatusRetrieved(boolean isCourseOpen) {
                if (isCourseOpen) {
                    binding.startCourseButton.setVisibility(View.GONE);
                    binding.endCourseButton.setVisibility(View.VISIBLE);
                } else {
                    binding.startCourseButton.setVisibility(View.VISIBLE);
                    binding.endCourseButton.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(MainActivity2.this, "Failed to check course status: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startAttendance(Location location) {
        manager.startCourseAttendance(userId, courseId, location, new TeacherManager.AttendanceListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(MainActivity2.this, "Attendance started", Toast.LENGTH_SHORT).show();
                studentAttendanceList.clear();
                adapter.notifyDataSetChanged();
                binding.startCourseButton.setVisibility(View.GONE);
                binding.endCourseButton.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(MainActivity2.this, "Failed to start attendance: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void endAttendance() {
        manager.endCourseAttendance(courseId, new TeacherManager.AttendanceListener() {
            @Override
            public void onSuccess() {
                manager.getStudentAttendanceStatus(courseId, new TeacherManager.AttendanceStatusListener() {
                    @Override
                    public void onStatusRetrieved(List<String> statuses) {
                        studentAttendanceList.clear();
                        studentAttendanceList.addAll(statuses);
                        adapter.notifyDataSetChanged();

                        // Display the statuses for a while before resetting
                        new android.os.Handler().postDelayed(() -> {
                            manager.resetAllAttendanceRecords(courseId, new TeacherManager.AttendanceListener() {
                                @Override
                                public void onSuccess() {
                                    Toast.makeText(MainActivity2.this, "Attendance reset", Toast.LENGTH_SHORT).show();
                                    binding.startCourseButton.setVisibility(View.VISIBLE);
                                    binding.endCourseButton.setVisibility(View.GONE);
                                }

                                @Override
                                public void onFailure(String errorMessage) {
                                    Toast.makeText(MainActivity2.this, "Failed to reset attendance records: " + errorMessage, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }, 5000); // Display statuses for 5 seconds
                    }

                    @Override
                    public void onFailure(String errorMessage) {
                        Toast.makeText(MainActivity2.this, "Failed to retrieve attendance status: " + errorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(MainActivity2.this, "Failed to end attendance: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
