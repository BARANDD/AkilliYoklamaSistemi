package com.example.akilliyoklamasistemi.models;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

import java.util.ArrayList;
import java.util.List;

public class MergeLiveData {

    public static <T> LiveData<List<T>> merge(List<LiveData<T>> sources) {
        MediatorLiveData<List<T>> result = new MediatorLiveData<>();
        List<T> currentValues = new ArrayList<>(sources.size());

        for (int i = 0; i < sources.size(); i++) {
            currentValues.add(null);
        }

        for (int i = 0; i < sources.size(); i++) {
            final int index = i;
            result.addSource(sources.get(i), value -> {
                currentValues.set(index, value);
                result.setValue(new ArrayList<>(currentValues));
            });
        }

        return result;
    }
}
