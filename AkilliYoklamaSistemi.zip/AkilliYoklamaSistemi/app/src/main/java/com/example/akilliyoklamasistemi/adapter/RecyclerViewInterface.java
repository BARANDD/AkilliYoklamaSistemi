package com.example.akilliyoklamasistemi.adapter;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
