package com.example.akilliyoklamasistemi.fragments;

import android.location.Location;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.akilliyoklamasistemi.databinding.FragmentCreateCourseBinding;
import com.example.akilliyoklamasistemi.managers.TeacherManager;
import com.example.akilliyoklamasistemi.view.TeacherActivity;

public class CreateCourseFragment extends Fragment {

    FragmentCreateCourseBinding binding;
    private TeacherManager teacherManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        teacherManager = new TeacherManager(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCreateCourseBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseName = binding.courseNameEditText.getText().toString();
                if (courseName.isEmpty()){
                    Toast.makeText(getActivity(), "Please enter an course name.", Toast.LENGTH_SHORT).show();
                    return;
                }

                teacherManager.createCourse(courseName, new TeacherManager.CourseCreateListener() {

                    @Override
                    public void onSuccess(String courseId, String enrollmentCode) {
                        Toast.makeText(getActivity(), "Successfully created the course.", Toast.LENGTH_SHORT).show();
                        if (getActivity() instanceof TeacherActivity) {
                            ((TeacherActivity) getActivity()).refreshTeacherHomeFragment();
                        }
                    }

                    @Override
                    public void onFailure(String errorMessage) {
                        Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
