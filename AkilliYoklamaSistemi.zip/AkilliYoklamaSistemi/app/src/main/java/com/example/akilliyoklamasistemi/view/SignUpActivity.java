package com.example.akilliyoklamasistemi.view;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.akilliyoklamasistemi.managers.AuthService;
import com.example.akilliyoklamasistemi.managers.DeviceUtil;
import com.example.akilliyoklamasistemi.databinding.ActivitySignUpBinding;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {

    FirebaseAuth mAut;
    private ActivitySignUpBinding binding;
    private AuthService authService;

    String deviceId;
    String role = "Student";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAut = FirebaseAuth.getInstance();
        authService = new AuthService();
        deviceId = DeviceUtil.getDeviceId(this);

        binding.roleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                role = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void singUp(View view) {
        String email = binding.email.getText().toString();
        String password = binding.signUpPassword.getText().toString();
        String username = binding.signUpUsername.getText().toString();
        role = binding.roleSpinner.getSelectedItem().toString();

        if (email.equals("") || password.equals("")) {
            Toast.makeText(this, "Enter email or password", Toast.LENGTH_SHORT).show();
        } else {
            authService.registerUser(email,username,password, role,deviceId, this);
        }

    }
}