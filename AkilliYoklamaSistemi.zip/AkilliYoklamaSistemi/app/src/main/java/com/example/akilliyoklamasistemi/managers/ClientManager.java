package com.example.akilliyoklamasistemi.managers;

import android.content.Context;
import android.Manifest;
import androidx.core.app.ActivityCompat;
import android.content.pm.PackageManager;
import android.location.Location;
import android.util.Log;

import com.example.akilliyoklamasistemi.models.CourseModel;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ClientManager {

    private final FirebaseAuth mAuth;
    private final FirebaseFirestore db;

    private FusedLocationProviderClient fusedLocationClient;

    private final Context context;

    public ClientManager(Context context) {
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
        this.context = context;
    }
    public interface ChangePasswordListener {
        void onSuccess();
        void onFailure(String errorMessage);
    }

    public void changePassword(String currentPassword, String newPassword, ChangePasswordListener changePasswordListener) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            user.updatePassword(newPassword)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            changePasswordListener.onSuccess();
                        } else {
                            changePasswordListener.onFailure("Failed to update password. Please try again.");
                        }
                    });
        }
    }
    // --------------------- Ders Kayıt -------------------------------------------
    public interface CourseRegistrationListener {
        void onRegistrationSuccess();
        void onRegistrationFailure(String errorMessage);
    }

    public void registerForCourse(String enrollmentCode, CourseRegistrationListener courseRegistrationListener) {
        if (!hasLocationPermission()) {
            courseRegistrationListener.onRegistrationFailure("Location permissions are not granted.");
            return;
        }

        try {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    // Konum alındı, kaydı gerçekleştirin
                    registerCourseWithLocation(enrollmentCode, courseRegistrationListener, location);
                } else {
                    courseRegistrationListener.onRegistrationFailure("Unable to get current location.");
                }
            }).addOnFailureListener(e -> {
                courseRegistrationListener.onRegistrationFailure("Failed to get location: " + e.getMessage());
            });
        } catch (SecurityException e) {
            courseRegistrationListener.onRegistrationFailure("SecurityException: " + e.getMessage());
        }
    }

    private boolean hasLocationPermission() {
        return ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void registerCourseWithLocation(String enrollmentCode, CourseRegistrationListener courseRegistrationListener, Location location) {
        String userId = mAuth.getCurrentUser().getUid();

        Task<DocumentSnapshot> userTask = db.collection("users").document(userId).get();
        Task<QuerySnapshot> courseTask = db.collection("courses").whereEqualTo("enrollment_code", enrollmentCode).get();

        Tasks.whenAllComplete(userTask, courseTask).addOnCompleteListener(tasks -> {
            if (!tasks.getResult().get(0).isSuccessful() || !tasks.getResult().get(1).isSuccessful()) {
                courseRegistrationListener.onRegistrationFailure("Failed to fetch data from the database.");
                return;
            }

            DocumentSnapshot userDoc = userTask.getResult();
            QuerySnapshot courseDocs = courseTask.getResult();

            if (userDoc == null || !userDoc.exists()) {
                courseRegistrationListener.onRegistrationFailure("User not found.");
                return;
            }

            if (courseDocs == null || courseDocs.isEmpty()) {
                courseRegistrationListener.onRegistrationFailure("Invalid enrollment code.");
                return;
            }

            String courseId = courseDocs.getDocuments().get(0).getId();
            List<String> enrolledCourses = (List<String>) userDoc.get("enrolledCourses");

            if (enrolledCourses != null && enrolledCourses.contains(courseId)) {
                courseRegistrationListener.onRegistrationFailure("You are already registered for this course.");
                return;
            }

            registerUserForCourse(userId, courseId, location, courseRegistrationListener);
        });
    }

    private void registerUserForCourse(String userId, String courseId, Location location, CourseRegistrationListener courseRegistrationListener) {
        WriteBatch batch = db.batch();

        DocumentReference userRef = db.collection("users").document(userId);
        DocumentReference courseRef = db.collection("courses").document(courseId);
        DocumentReference attendanceRef = db.collection("attendanceRecords").document(userId + "_" + courseId);

        batch.update(userRef, "enrolledCourses", FieldValue.arrayUnion(courseId));
        batch.update(courseRef, "students", FieldValue.arrayUnion(userId));

        Map<String, Object> attendanceRecord = new HashMap<>();
        attendanceRecord.put("attendance_count", 0);
        attendanceRecord.put("last_attendance_time", Timestamp.now());
        attendanceRecord.put("last_known_location", new GeoPoint(location.getLatitude(), location.getLongitude()));
        attendanceRecord.put("gaveAttendance",false);
        batch.set(attendanceRef, attendanceRecord);

        batch.commit().addOnSuccessListener(aVoid -> {
            courseRegistrationListener.onRegistrationSuccess();
        }).addOnFailureListener(e -> {
            courseRegistrationListener.onRegistrationFailure("Failed to register for the course. Please try again.");
        });
    }


    // ----------------------Kurs datalarını çekme ------------------------------------------
    public void getUserEnrolledCourseDetails(String userId, OnEnrolledCourseDetailsListener listener) {
        db.collection("users").document(userId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        DocumentSnapshot userDocument = task.getResult();
                        List<String> enrolledCourses = (List<String>) userDocument.get("enrolledCourses");
                        if (enrolledCourses != null && !enrolledCourses.isEmpty()) {
                            fetchCoursesDetails(enrolledCourses, listener);
                        } else {
                            listener.onFailure("No enrolled courses found.");
                        }
                    } else {
                        listener.onFailure("Failed to fetch user details.");
                    }
                });
    }

    private void fetchCoursesDetails(List<String> courseIds, OnEnrolledCourseDetailsListener listener) {
        List<Task<DocumentSnapshot>> tasks = new ArrayList<>();
        for (String courseId : courseIds) {
            tasks.add(db.collection("courses").document(courseId).get());
        }
        Tasks.whenAllComplete(tasks).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (Task<DocumentSnapshot> courseTask : tasks) {
                    if (courseTask.isSuccessful() && courseTask.getResult() != null) {
                        DocumentSnapshot courseDocument = courseTask.getResult();
                        String courseName = courseDocument.getString("course_name");
                        String teacherId = courseDocument.getString("teacher_id");
                        if (courseName != null && teacherId != null) {
                            fetchTeacherDetails(courseName, teacherId, listener);
                        } else {
                            listener.onFailure("Course name or teacher ID not found.");
                        }
                    } else {
                        listener.onFailure("Failed to fetch course details.");
                    }
                }
            } else {
                listener.onFailure("Failed to fetch courses.");
            }
        });
    }

    private void fetchTeacherDetails(String courseName, String teacherId, OnEnrolledCourseDetailsListener listener) {
        db.collection("users").document(teacherId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        DocumentSnapshot teacherDocument = task.getResult();
                        String teacherName = teacherDocument.getString("username");
                        if (teacherName != null) {
                            CourseModel courseDetails = new CourseModel(courseName, teacherName);
                            listener.onCourseDetailsFetched(courseDetails);
                        } else {
                            listener.onFailure("Teacher name not found.");
                        }
                    } else {
                        listener.onFailure("Failed to fetch teacher details.");
                    }
                });
    }
//---------------------------------------------------------------------

    public interface OnEnrolledCourseDetailsListener {
        void onCourseDetailsFetched(CourseModel courseDetails);
        void onFailure(String errorMessage);
    }

    public interface CourseDetailsListener {
        void onCourseDetailsFetched(String teacherId, boolean isCourseStarted, String courseId);
        void onFailure(String errorMessage);
    }

    public void fetchCourseDetails(String courseName, String teacherName, CourseDetailsListener listener) {
        Query teacherQuery = db.collection("users")
                .whereEqualTo("username", teacherName)
                .limit(1);

        teacherQuery.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                QuerySnapshot teacherSnapshot = task.getResult();
                if (!teacherSnapshot.isEmpty()) {
                    DocumentSnapshot teacherDoc = teacherSnapshot.getDocuments().get(0);
                    String teacherId = teacherDoc.getId();

                    Query courseQuery = db.collection("courses")
                            .whereEqualTo("course_name", courseName)
                            .whereEqualTo("teacher_id", teacherId)
                            .limit(1);

                    courseQuery.get().addOnCompleteListener(courseTask -> {
                        if (courseTask.isSuccessful()) {
                            QuerySnapshot courseSnapshot = courseTask.getResult();
                            if (!courseSnapshot.isEmpty()) {
                                DocumentSnapshot courseDoc = courseSnapshot.getDocuments().get(0);
                                boolean isCourseStarted = courseDoc.getBoolean("attendance_started");
                                String courseId = courseDoc.getId();

                                listener.onCourseDetailsFetched(teacherId, isCourseStarted, courseId);
                            } else {
                                listener.onFailure("Course not found");
                            }
                        } else {
                            listener.onFailure("Failed to fetch course details: " + courseTask.getException().getMessage());
                        }
                    });
                } else {
                    listener.onFailure("Teacher not found");
                }
            } else {
                listener.onFailure("Failed to fetch teacher details: " + task.getException().getMessage());
            }
        });
    }
//--------------------------------Yoklama vermek için ----------------------------------
public void markAttendance(String userId, String courseId, Location studentLocation, OnAttendanceMarkedListener listener) {
    // Check if the attendance for the course has started and not ended
    db.collection("courses").document(courseId).get().addOnCompleteListener(task -> {
        if (task.isSuccessful() && task.getResult() != null) {
            DocumentSnapshot courseDoc = task.getResult();
            Boolean isAttendanceStarted = courseDoc.getBoolean("attendance_started");
            Boolean isAttendanceEnded = courseDoc.getBoolean("attendance_ended");

            if (Boolean.TRUE.equals(isAttendanceStarted) && Boolean.FALSE.equals(isAttendanceEnded)) {
                String teacherId = courseDoc.getString("teacher_id");
                checkStudentAttendanceStatus(userId, teacherId, studentLocation, courseId, listener);
            } else {
                listener.onFailure("Attendance for this course has not started or has already ended.");
            }
        } else {
            listener.onFailure("Failed to retrieve course details.");
        }
    });
}

    private void checkStudentAttendanceStatus(String studentId, String teacherId, Location studentLocation, String courseId, OnAttendanceMarkedListener listener) {
        // Check if the student has already marked attendance
        db.collection("attendanceRecords").document(studentId + "_" + courseId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot studentAttendanceDoc = task.getResult();
                Boolean gaveAttendance = studentAttendanceDoc.getBoolean("gaveAttendance");

                if (Boolean.FALSE.equals(gaveAttendance)) {
                    checkTeacherProximity(studentId, teacherId, studentLocation, courseId, listener);
                } else {
                    listener.onFailure("Attendance has already been marked.");
                }
            } else {
                listener.onFailure("Failed to retrieve student attendance record.");
            }
        });
    }

    private void checkTeacherProximity(String studentId, String teacherId, Location studentLocation, String courseId, OnAttendanceMarkedListener listener) {
        // Get the teacher's last known location
        db.collection("attendanceRecords").document(teacherId + "_" + courseId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot teacherAttendanceDoc = task.getResult();
                GeoPoint teacherLocationGeoPoint = teacherAttendanceDoc.getGeoPoint("last_known_location");

                if (teacherLocationGeoPoint != null) {
                    Location teacherLocation = new Location("");
                    teacherLocation.setLatitude(teacherLocationGeoPoint.getLatitude());
                    teacherLocation.setLongitude(teacherLocationGeoPoint.getLongitude());

                    if (isWithinProximity(studentLocation, teacherLocation)) {
                        updateAttendanceRecord(studentId, studentLocation, courseId, listener);
                    } else {
                        listener.onFailure("You are not close enough to the teacher.");
                    }
                } else {
                    listener.onFailure("Incomplete teacher attendance record.");
                }
            } else {
                listener.onFailure("Failed to retrieve teacher attendance record.");
            }
        });
    }

    private boolean isWithinProximity(Location studentLocation, Location teacherLocation) {
        float distance = studentLocation.distanceTo(teacherLocation);
        return distance <= 100;
    }

    private void updateAttendanceRecord(String studentId, Location studentLocation, String courseId, OnAttendanceMarkedListener listener) {
        DocumentReference docRef = db.collection("attendanceRecords").document(studentId + "_" + courseId);

        db.runTransaction(transaction -> {
            DocumentSnapshot document = transaction.get(docRef);
            Long currentAttendanceCount = document.getLong("attendance_count");
            if (currentAttendanceCount == null) {
                currentAttendanceCount = 0L;
            }

            Map<String, Object> attendanceData = new HashMap<>();
            attendanceData.put("attendance_count", currentAttendanceCount + 1);
            attendanceData.put("last_attendance_time", Timestamp.now());
            attendanceData.put("last_known_location", new GeoPoint(studentLocation.getLatitude(), studentLocation.getLongitude()));
            attendanceData.put("gaveAttendance", true);
            transaction.update(docRef, attendanceData);

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d("AttendanceUpdate", "Attendance record successfully updated.");
            listener.onAttendanceMarked();
        }).addOnFailureListener(e -> {
            Log.e("AttendanceUpdate", "Failed to update attendance record: " + e.getMessage(), e);
            listener.onFailure("Failed to update attendance record: " + e.getMessage());
        });
    }

    public interface OnAttendanceMarkedListener {
        void onAttendanceMarked();
        void onFailure(String errorMessage);
    }

}





