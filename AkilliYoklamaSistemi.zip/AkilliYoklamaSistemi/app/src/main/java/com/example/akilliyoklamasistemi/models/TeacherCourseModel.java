package com.example.akilliyoklamasistemi.models;

public class TeacherCourseModel {

    private String courseName;
    private String courseId;
    public TeacherCourseModel(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseName() {
        return courseName;
    }
}
