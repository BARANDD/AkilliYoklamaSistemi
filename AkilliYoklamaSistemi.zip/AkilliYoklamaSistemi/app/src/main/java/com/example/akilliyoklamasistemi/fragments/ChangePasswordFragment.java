package com.example.akilliyoklamasistemi.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.akilliyoklamasistemi.databinding.FragmentChangePasswordBinding;
import com.example.akilliyoklamasistemi.managers.ClientManager;

public class ChangePasswordFragment extends Fragment {

    private FragmentChangePasswordBinding binding;
    private ClientManager clientManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clientManager = new ClientManager(requireContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentChangePasswordBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.changePasswordButton.setOnClickListener(v -> {
            String currentPassword = binding.currentPasswordEditText.getText().toString().trim();
            String newPassword = binding.newPasswordEditText.getText().toString().trim();
            clientManager.changePassword(currentPassword, newPassword, new ClientManager.ChangePasswordListener() {
                @Override
                public void onSuccess() {
                    Toast.makeText(requireContext(), "Password updated successfully.", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(String errorMessage) {
                    Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show();
                }
            });
        });
    }



}
