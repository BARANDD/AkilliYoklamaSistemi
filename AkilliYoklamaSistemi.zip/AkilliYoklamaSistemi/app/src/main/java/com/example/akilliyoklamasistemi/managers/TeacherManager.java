package com.example.akilliyoklamasistemi.managers;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TeacherManager {

    private final FirebaseAuth mAuth;
    private final FirebaseFirestore db;
    private final FusedLocationProviderClient fusedLocationClient;

    private final Context context;

    public TeacherManager(Context context) {
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
        this.context = context;
    }



    public interface CourseDetailsListener{
        void onSuccess(String courseId,String enrollmentCode);
        void onFailure(String errorMessage);
    }



    public interface CourseNameListener {
        void onSuccess(String courseName);
        void onFailure(String errorMessage);
    }

    public interface TeachingCoursesListener {
        void onSuccess(ArrayList<String> courseIds);
        void onFailure(String errorMessage);
    }

    // --------------------- Ders oluşturma -------------------




    public interface CourseCreateListener {
        void onSuccess(String courseId, String enrollmentCode);
        void onFailure(String errorMessage);
    }
    public void createCourse(String courseName, CourseCreateListener courseCreationListener) {
        if (!hasLocationPermission()) {
            courseCreationListener.onFailure("Location permissions are not granted.");
            return;
        }

        try {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    // Konum alındı, ders oluşturulacak
                    createCourseWithLocation(courseName, courseCreationListener, location);
                } else {
                    courseCreationListener.onFailure("Unable to get current location.");
                }
            }).addOnFailureListener(e -> {
                courseCreationListener.onFailure("Failed to get location: " + e.getMessage());
            });
        } catch (SecurityException e) {
            courseCreationListener.onFailure("SecurityException: " + e.getMessage());
        }
    }

    private boolean hasLocationPermission() {
        return ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void createCourseWithLocation(String courseName, CourseCreateListener courseCreationListener, Location location) {
        String teacherId = mAuth.getCurrentUser().getUid();

        Task<DocumentSnapshot> userTask = db.collection("users").document(teacherId).get();

        userTask.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    List<String> teachingCourses = (List<String>) document.get("teachingCourses");
                    if (teachingCourses != null && !teachingCourses.isEmpty()) {
                        checkIfCourseExists(courseName, teachingCourses, exists -> {
                            if (exists) {
                                courseCreationListener.onFailure("A course with the same name already exists");
                            } else {
                                createNewCourse(courseName, teacherId, courseCreationListener, location);
                            }
                        });
                    } else {
                        createNewCourse(courseName, teacherId, courseCreationListener, location);
                    }
                } else {
                    courseCreationListener.onFailure("Teacher document not found");
                }
            } else {
                courseCreationListener.onFailure("Database error");
            }
        });
    }

    private void checkIfCourseExists(String courseName, List<String> teachingCourses, OnCourseExistenceCheckListener listener) {
        db.collection("courses")
                .whereIn(FieldPath.documentId(), teachingCourses)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        boolean courseExists = false;
                        for (DocumentSnapshot courseDoc : task.getResult().getDocuments()) {
                            String existingCourseName = courseDoc.getString("course_name");
                            if (courseName.equals(existingCourseName)) {
                                courseExists = true;
                                break;
                            }
                        }
                        listener.onCheckComplete(courseExists);
                    } else {
                        listener.onCheckComplete(false);
                    }
                });
    }

    private void createNewCourse(String courseName, String teacherId, CourseCreateListener courseCreationListener, Location location) {
        String courseId = db.collection("courses").document().getId();
        String enrollmentCode = generateEnrollmentCode();
        Map<String, Object> course = new HashMap<>();
        course.put("course_name", courseName);
        course.put("teacher_id", teacherId);
        course.put("enrollment_code", enrollmentCode);
        course.put("attendance_started", false);
        course.put("attendance_ended", false);
        course.put("students", new ArrayList<>());

        WriteBatch batch = db.batch();
        DocumentReference courseRef = db.collection("courses").document(courseId);
        batch.set(courseRef, course);

        DocumentReference userRef = db.collection("users").document(teacherId);
        batch.update(userRef, "teachingCourses", FieldValue.arrayUnion(courseId));

        batch.commit().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                createAttendanceRecord(courseId, teacherId, location, success -> {
                    if (success) {
                        courseCreationListener.onSuccess(courseId, enrollmentCode);
                    } else {
                        courseCreationListener.onFailure("Failed to create attendance record");
                    }
                });
            } else {
                courseCreationListener.onFailure("Failed to create course");
            }
        });
    }

    private void createAttendanceRecord(String courseId, String teacherId, Location location, OnAttendanceRecordCreationListener listener) {
        Map<String, Object> attendanceRecord = new HashMap<>();
        attendanceRecord.put("attendance_count", 0);
        attendanceRecord.put("last_attendance_time", Timestamp.now());
        attendanceRecord.put("last_known_location", new GeoPoint(location.getLatitude(), location.getLongitude()));
        attendanceRecord.put("gaveAttendance",false);

        db.collection("attendanceRecords").document(teacherId + "_" + courseId)
                .set(attendanceRecord)
                .addOnSuccessListener(aVoid -> listener.onCreationComplete(true))
                .addOnFailureListener(e -> listener.onCreationComplete(false));
    }

    private interface OnCourseExistenceCheckListener {
        void onCheckComplete(boolean exists);
    }

    private interface OnAttendanceRecordCreationListener {
        void onCreationComplete(boolean success);
    }






    private String generateEnrollmentCode() {
        // Rastgele bir kayıt kodu oluştur
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (int i = 0; i < 6; i++) {
            int index = random.nextInt(characters.length());
            sb.append(characters.charAt(index));
        }
        return sb.toString();
    }

    //-------------------------- RecyclerView için data çekme -----------------------------------

    public LiveData<List<String>> getTeachingCourses() {
        MutableLiveData<List<String>> coursesLiveData = new MutableLiveData<>();
        String teacherId = mAuth.getCurrentUser().getUid();

        db.collection("users").document(teacherId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                DocumentSnapshot documentSnapshot = task.getResult();
                List<String> teachingCourses = (List<String>) documentSnapshot.get("teachingCourses");
                if (teachingCourses != null) {
                    coursesLiveData.setValue(teachingCourses);
                } else {
                    coursesLiveData.setValue(new ArrayList<>());
                }
            } else {
                coursesLiveData.setValue(new ArrayList<>());
            }
        });

        return coursesLiveData;
    }

    public LiveData<String> getCourseName(String courseId) {
        MutableLiveData<String> courseNameLiveData = new MutableLiveData<>();

        db.collection("courses").document(courseId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                DocumentSnapshot documentSnapshot = task.getResult();
                String courseName = documentSnapshot.getString("course_name");
                if (courseName != null) {
                    courseNameLiveData.setValue(courseName);
                } else {
                    courseNameLiveData.setValue(null);
                }
            } else {
                courseNameLiveData.setValue(null);
            }
        });

        return courseNameLiveData;
    }

    public void findCourseDetails(String courseName, CourseDetailsListener listener) {
        String userId = mAuth.getCurrentUser().getUid();
        if (userId == null) {
            listener.onFailure("User ID not found");
            return;
        }

        // Firestore sorgusu kullanarak kurs ayrıntılarını al
        db.collection("courses")
                .whereEqualTo("course_name", courseName)
                .whereEqualTo("teacher_id", userId)
                .limit(1) // Sadece ilk eşleşen belgeyi al
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (!querySnapshot.isEmpty()) {
                            DocumentSnapshot documentSnapshot = querySnapshot.getDocuments().get(0);
                            String courseId = documentSnapshot.getId();
                            String enrollmentCode = documentSnapshot.getString("enrollment_code");
                            listener.onSuccess(courseId, enrollmentCode);
                        } else {
                            listener.onFailure("Course not found");
                        }
                    } else {
                        listener.onFailure("Failed to get course details: " + task.getException().getMessage());
                    }
                });
    }


    public String getUserId() {
        if (mAuth.getCurrentUser() != null) {
            return mAuth.getCurrentUser().getUid();
        } else {
            return null;
        }
    }

//-------------------------- Yoklama başlatma ve bitirme kodları ---------------------------------
public interface AttendanceListener {
    void onSuccess();
    void onFailure(String errorMessage);
}

    public interface AttendanceStatusListener {
        void onStatusRetrieved(List<String> statuses);
        void onFailure(String errorMessage);
    }

    public interface CourseStatusListener {
        void onStatusRetrieved(boolean isCourseOpen);
        void onFailure(String errorMessage);
    }

    public void checkCourseStatus(String courseId, CourseStatusListener listener) {
        db.collection("courses").document(courseId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot courseDoc = task.getResult();
                Boolean isAttendanceStarted = courseDoc.getBoolean("attendance_started");
                Boolean isAttendanceEnded = courseDoc.getBoolean("attendance_ended");

                if (Boolean.TRUE.equals(isAttendanceStarted) && Boolean.FALSE.equals(isAttendanceEnded)) {
                    listener.onStatusRetrieved(true);
                } else {
                    listener.onStatusRetrieved(false);
                }
            } else {
                listener.onFailure("Failed to retrieve course status: " + task.getException().getMessage());
            }
        });
    }

    public void startCourseAttendance(String userId, String courseId, Location location, AttendanceListener listener) {
        db.collection("courses").document(courseId).update("attendance_started", true, "attendance_ended", false)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        updateAttendanceRecord(userId, courseId, location, true, listener);
                    } else {
                        listener.onFailure("Failed to start course attendance: " + task.getException().getMessage());
                    }
                });
    }

    private void updateAttendanceRecord(String userId, String courseId, Location location, boolean gaveAttendance, AttendanceListener listener) {
        DocumentReference docRef = db.collection("attendanceRecords").document(userId + "_" + courseId);

        db.runTransaction(transaction -> {
            DocumentSnapshot document = transaction.get(docRef);

            Long currentAttendanceCount = document.getLong("attendance_count");
            if (currentAttendanceCount == null) {
                currentAttendanceCount = 0L;
            }

            long newAttendanceCount = currentAttendanceCount + 1;

            Map<String, Object> attendanceRecordUpdates = new HashMap<>();
            attendanceRecordUpdates.put("attendance_count", newAttendanceCount);
            attendanceRecordUpdates.put("last_attendance_time", Timestamp.now());
            attendanceRecordUpdates.put("last_known_location", new GeoPoint(location.getLatitude(), location.getLongitude()));
            attendanceRecordUpdates.put("gaveAttendance", gaveAttendance);

            transaction.update(docRef, attendanceRecordUpdates);

            return null;
        }).addOnSuccessListener(aVoid -> {
            listener.onSuccess();
        }).addOnFailureListener(e -> {
            listener.onFailure("Failed to update course attendance record: " + e.getMessage());
        });
    }

    public void endCourseAttendance(String courseId, AttendanceListener listener) {
        db.collection("courses").document(courseId).update("attendance_started", false, "attendance_ended", true)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        listener.onSuccess();
                    } else {
                        listener.onFailure("Failed to end course attendance: " + task.getException().getMessage());
                    }
                });
    }

    public void resetAllAttendanceRecords(String courseId, AttendanceListener listener) {
        DocumentReference courseRef = db.collection("courses").document(courseId);
        courseRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot courseDoc = task.getResult();
                List<String> students = (List<String>) courseDoc.get("students");
                String teacherId = courseDoc.getString("teacher_id");

                WriteBatch batch = db.batch();
                if (teacherId != null) {
                    DocumentReference teacherDocRef = db.collection("attendanceRecords").document(teacherId + "_" + courseId);
                    batch.update(teacherDocRef, "gaveAttendance", false);
                }

                if (students != null) {
                    for (String studentId : students) {
                        DocumentReference studentDocRef = db.collection("attendanceRecords").document(studentId + "_" + courseId);
                        batch.update(studentDocRef, "gaveAttendance", false);
                    }
                }

                batch.commit().addOnSuccessListener(aVoid -> {
                    listener.onSuccess();
                }).addOnFailureListener(e -> {
                    listener.onFailure("Failed to reset attendance records: " + e.getMessage());
                });
            } else {
                listener.onFailure("Failed to retrieve course details: " + task.getException().getMessage());
            }
        });
    }

    public void getStudentAttendanceStatus(String courseId, AttendanceStatusListener listener) {
        DocumentReference courseRef = db.collection("courses").document(courseId);
        courseRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot courseDoc = task.getResult();
                List<String> students = (List<String>) courseDoc.get("students");
                String teacherId = courseDoc.getString("teacher_id");

                if (teacherId != null) {
                    db.collection("attendanceRecords").document(teacherId + "_" + courseId).get().addOnCompleteListener(teacherTask -> {
                        if (teacherTask.isSuccessful() && teacherTask.getResult() != null) {
                            DocumentSnapshot teacherDoc = teacherTask.getResult();
                            Long teacherAttendanceCount = teacherDoc.getLong("attendance_count");

                            List<String> statuses = new ArrayList<>();
                            if (students != null) {
                                for (String studentId : students) {
                                    db.collection("users").document(studentId).get().addOnCompleteListener(userTask -> {
                                        if (userTask.isSuccessful() && userTask.getResult() != null) {
                                            String studentName = userTask.getResult().getString("username");
                                            db.collection("attendanceRecords").document(studentId + "_" + courseId).get().addOnCompleteListener(studentTask -> {
                                                if (studentTask.isSuccessful() && studentTask.getResult() != null) {
                                                    DocumentSnapshot studentDoc = studentTask.getResult();
                                                    Boolean gaveAttendance = studentDoc.getBoolean("gaveAttendance");
                                                    Long studentAttendanceCount = studentDoc.getLong("attendance_count");

                                                    String status;
                                                    if (Boolean.TRUE.equals(gaveAttendance)) {
                                                        status = "Yoklama Verdi";
                                                    } else {
                                                        status = "Yoklama Vermedi";
                                                    }

                                                    if (teacherAttendanceCount != null && studentAttendanceCount != null) {
                                                        if ((teacherAttendanceCount - studentAttendanceCount) > 4) {
                                                            status += " - Dersten Kaldı";
                                                        }
                                                    }

                                                    statuses.add(studentName + ": " + status);
                                                    if (statuses.size() == students.size()) {
                                                        listener.onStatusRetrieved(statuses);
                                                    }
                                                }
                                            });
                                        }
                                    });
                                }
                            } else {
                                listener.onStatusRetrieved(statuses);
                            }
                        } else {
                            listener.onFailure("Failed to retrieve teacher attendance count.");
                        }
                    });
                } else {
                    listener.onFailure("Teacher ID is null.");
                }
            } else {
                listener.onFailure("Failed to retrieve course details.");
            }
        });
    }
}





