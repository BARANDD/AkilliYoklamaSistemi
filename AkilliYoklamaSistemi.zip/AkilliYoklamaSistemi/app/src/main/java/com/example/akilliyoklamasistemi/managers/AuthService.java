package com.example.akilliyoklamasistemi.managers;
import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.akilliyoklamasistemi.view.LoginActivity;
import com.example.akilliyoklamasistemi.view.SignUpActivity;
import com.example.akilliyoklamasistemi.view.StudentActivity;
import com.example.akilliyoklamasistemi.view.TeacherActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AuthService {
    private final FirebaseAuth mAuth;
    private final FirebaseFirestore db;

    public AuthService() {
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    public void registerUser(String email,String username,String password,String role,String deviceId,Context context) {
        mAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                FirebaseUser user = mAuth.getCurrentUser();
                 Map<String,Object> newUser = new HashMap<>();
                newUser.put("email", email);
                newUser.put("username",username);
                newUser.put("role", role);
                newUser.put("deviceId", deviceId);

                if (role.equals("student")) {
                    newUser.put("enrolledCourses", new ArrayList<String>());
                } else if (role.equals("teacher")) {
                    newUser.put("teachingCourses", new ArrayList<String>());
                }

               db.collection("users").document(user.getUid()).set(newUser).addOnSuccessListener(new OnSuccessListener<Void>() {
                   @Override
                   public void onSuccess(Void unused) {
                       Toast.makeText(context,"Kullanici Kayıdı Basarılı",Toast.LENGTH_SHORT).show();
                       Intent intent;
                       if ("Student".equals(role)) {
                           intent = new Intent(context, StudentActivity.class);
                       } else {
                           intent = new Intent(context, TeacherActivity.class);
                       }
                       context.startActivity(intent);

                       if (context instanceof SignUpActivity) {
                           ((SignUpActivity) context).finish();
                       }
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Toast.makeText(context,"Kullanici Kayıdı Basarısız",Toast.LENGTH_SHORT).show();
                   }
               });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(context, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void Login(String email,String password,String currentDeviceId,Context context){
        mAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null){
                    db.collection("users").document(user.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()){
                                String registerDeviceId = documentSnapshot.getString("deviceId");
                                String role = documentSnapshot.getString("role");
                                if (currentDeviceId.equals(registerDeviceId)){
                                    Toast.makeText(context,"Giriş Başarılı",Toast.LENGTH_SHORT).show();
                                    Intent intent;
                                    if ("Student".equals(role)) {
                                        intent = new Intent(context, StudentActivity.class);
                                    } else {
                                        intent = new Intent(context, TeacherActivity.class);
                                    }
                                    context.startActivity(intent);

                                    if (context instanceof LoginActivity) {
                                        ((LoginActivity) context).finish();
                                    }

                                }
                                else {
                                    Toast.makeText(context,"Hata: Cihaz kimliği eşleşmiyor",Toast.LENGTH_SHORT).show();
                                    mAuth.signOut();
                                }
                            }
                        }
                    });
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(context,e.getLocalizedMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

}
