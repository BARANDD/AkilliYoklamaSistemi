package com.example.akilliyoklamasistemi.view;

import android.os.Bundle;
import android.widget.Toast;
import android.Manifest;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.adapter.viewPagerAdapter;
import com.example.akilliyoklamasistemi.adapter.viewPagerAdapter2;
import com.example.akilliyoklamasistemi.databinding.ActivityStudentBinding;
import com.example.akilliyoklamasistemi.databinding.ActivityTeacherBinding;
import com.example.akilliyoklamasistemi.fragments.TeacherHomeFragment;
import com.google.android.material.tabs.TabLayout;

public class TeacherActivity extends AppCompatActivity {

    ActivityTeacherBinding binding;
    viewPagerAdapter2 vpAdapter2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityTeacherBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        vpAdapter2 = new viewPagerAdapter2(this);
        binding.viewPager.setAdapter(vpAdapter2);

        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.tabLayout.getTabAt(position).select();
            }
        });

    }

    public void refreshTeacherHomeFragment() {
        TeacherHomeFragment teacherHomeFragment = new TeacherHomeFragment();
        vpAdapter2 = new viewPagerAdapter2(this);
        vpAdapter2.notifyDataSetChanged();
        binding.viewPager.setAdapter(vpAdapter2);

        // 2. ViewPager'ı ilk sekme konumuna getir
        binding.viewPager.setCurrentItem(0);
    }


}
