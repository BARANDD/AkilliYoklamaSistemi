package com.example.akilliyoklamasistemi.view;

import static androidx.constraintlayout.motion.widget.Debug.getLocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.databinding.ActivityMain3Binding;
import com.example.akilliyoklamasistemi.managers.ClientManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.firestore.GeoPoint;

public class MainActivity3 extends AppCompatActivity {
    ActivityMain3Binding binding;
    private FusedLocationProviderClient fusedLocationClient;
    private ClientManager clientManager;

    String teacherId;

    String courseId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMain3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        clientManager = new ClientManager(MainActivity3.this);


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        courseId = getIntent().getStringExtra("courseId");
        String courseName = getIntent().getStringExtra("courseName");
        String teacherName = getIntent().getStringExtra("teacherName");
        teacherId = getIntent().getStringExtra("teacherId");
        String userId = getIntent().getStringExtra("userId");
        boolean isCourseStarted = getIntent().getBooleanExtra("isCourseStarted", false);

        binding.courseNameTextView.setText(courseName);
        binding.teacherNameTextView.setText(teacherName);
        binding.attendanceStatusTextView.setText(isCourseStarted ? "Course Started" : "Course Not Started");

        binding.giveAttendanceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(MainActivity3.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(MainActivity3.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MainActivity3.this,"konum izni alınmadı",Toast.LENGTH_SHORT).show();
                    return;
                }

                fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                    if (location != null){
                        markAttendance(userId, location);
                    }else {
                        Toast.makeText(MainActivity3.this, "Konum bilgisi alınamadı.", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });
    }

    private void markAttendance(String userId, Location location) {
        // Yoklama işlemini gerçekleştirirken kullanılacak parametrelerle birlikte markAttendance fonksiyonunu çağır
        clientManager.markAttendance(userId,courseId, location, new ClientManager.OnAttendanceMarkedListener() {
            @Override
            public void onAttendanceMarked() {
                // Yoklama işlemi başarıyla işaretlendiğinde yapılacak işlemler
                Toast.makeText(MainActivity3.this, "Attendance marked successfully!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity3.this,StudentActivity.class);
                startActivity(intent);
            }

            @Override
            public void onFailure(String errorMessage) {
                // Yoklama işlemi sırasında bir hata oluştuğunda yapılacak işlemler
                Toast.makeText(MainActivity3.this, errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
