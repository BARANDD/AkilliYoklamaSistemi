package com.example.akilliyoklamasistemi.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.akilliyoklamasistemi.R;
import com.example.akilliyoklamasistemi.databinding.RecyclerItemCoursesBinding;
import com.example.akilliyoklamasistemi.models.CourseModel;
import java.util.ArrayList;

public class CourseFragmentAdapter extends RecyclerView.Adapter<CourseFragmentAdapter.MyViewHolder> {
    private  final RecyclerViewInterface recyclerViewInterface;
    Context context;
    ArrayList<CourseModel> courseModels;

    public CourseFragmentAdapter(Context context, ArrayList<CourseModel> courseModels,RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.courseModels = courseModels;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public CourseFragmentAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerItemCoursesBinding binding = RecyclerItemCoursesBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new MyViewHolder(binding,recyclerViewInterface);


    }

    @Override
    public void onBindViewHolder(@NonNull CourseFragmentAdapter.MyViewHolder holder, int position) {
        holder.binding.courseNameTextView.setText(courseModels.get(position).getCourseName());
        holder.binding.courseTeacher.setText(courseModels.get(position).getCourseTeacher());
    }


    @Override
    public int getItemCount() {
        return courseModels.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder{

        RecyclerItemCoursesBinding binding;

        public MyViewHolder(RecyclerItemCoursesBinding binding,RecyclerViewInterface recyclerViewInterface) {
            super(binding.getRoot());
            this.binding = binding;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (recyclerViewInterface != null){
                        int pos = getAdapterPosition();

                        if (pos != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });

        }
    }
}
